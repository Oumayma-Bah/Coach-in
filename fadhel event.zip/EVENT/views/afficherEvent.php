<?PHP
	include "../controller/EventC.php";

	$EventC=new EventC();
	$listeUsers=$EventC->afficherEvents();

?>

<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title> Afficher Liste Events </title>
    </head>
    <body>
		<button><a href="connexion.php">Ajouter un Event</a></button>
		<hr>
		<table border=1 align = 'center'>
			<tr>
				<th>Id</th>
				<th>Nom</th>
				<th>date</th>
				<th>duree</th>
				 
			</tr>

			<?PHP
				foreach($listeUsers as $user){
					 
			?>
				<tr>
					<td><?PHP echo $user['id']; ?></td>
					<td><?PHP echo $user['nom']; ?></td>
					<td><?PHP echo $user['dateE']; ?></td>
					<td><?PHP echo $user['duree']; ?></td>
 					<td>
						<form method="POST" action="supprimerEvent.php">
						<input type="submit" name="supprimer" value="supprimer">
						<input type="hidden" value=<?PHP echo $user['id']; ?> name="id">
						</form>
					</td>
					<td>
						<a href="modifierEvent.php?id=<?PHP echo $user['id']; ?>"> Modifier </a>
					</td>
				</tr>
			<?PHP
				}
			?>
		</table>
	</body>
</html>
