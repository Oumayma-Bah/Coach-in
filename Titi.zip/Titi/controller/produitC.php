<?PHP
include "C:/wamp64/www/titi/config.php";

class ProduitC {
	function ajouterProduit($produit){
		$sql="insert into products (name,prix,quantity,description,category) values (:name,:prix,:quantity,:description,:category)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $name=$produit->getName();
        $prix=$produit->getPrix();
        $quantity=$produit->getQuantity();
        $description=$produit->getDescription();
        $category=$produit->getCategory();
		$req->bindValue(':name',$name);
		$req->bindValue(':prix',$prix);
		$req->bindValue(':quantity',$quantity);
		$req->bindValue(':description',$description);
		$req->bindValue(':category',$category);
		$req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherProduits(){
		$sql="SElECT * From products";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    function afficherProduit($id){
        $sql="SELECT * From products where id=$id";
        $db = config::getConnexion();
        try{
            $req = $db->prepare($sql);
            $req->execute();
            foreach ($req as $row):
                {
                    return $row;
                }
            endforeach;


        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    
    function supprimerproduit($id){
            $sql="DELETE FROM products where id= :id";
            $db = config::getConnexion();
            $req=$db->prepare($sql);
            $req->bindValue(':id',$id);
            try{
                $req->execute();
            // header('Location: index.php');
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
	    }
        function modifierproduit($produit1,$id)
        {
            $sql="UPDATE products SET  name=:name,product_title=:product_title,prix=:prix,tax=:tax,quantity=:quantity,description=:description,sale=:sale,category=:category,size=:size  ,final_price=:final_price WHERE id=:id";
            
            $db = config::getConnexion();
            //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
            try{        
            $req=$db->prepare($sql);

            $name=$produit1->getname();
            $product_title=$produit1->getTitle();
            $prix=$produit1->getPrix();
            $tax=$produit1->getTax();
            $quantity=$produit1->getQuantity();
            $descreption=$produit1->getDescreption();
            $sale=$produit1->getSale();
            $category=$produit1->getCategory();
            $size=$produit1->getSize();
            $final_price=$produit1->getfinalprice();
            $req->bindValue(':name',$name);
            $req->bindValue(':product_title',$product_title);
            $req->bindValue(':prix',$prix);
            $req->bindValue(':tax',$tax);
            $req->bindValue(':quantity',$quantity);
            $req->bindValue(':descreption',$descreption);
            $req->bindValue(':sale',$sale);
            $req->bindValue(':category',$category);
            $req->bindValue(':size',$size);
            $req->bindValue(':final_price',$final_price);
            $req->bindValue(':numero',$numero);

            $req->execute();
            }
            catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
            }
        }

        function image($category)
        {
            $db = config::getConnexion();
            $select=$db->prepare("SELECT image from products where category=:category ");
            try{
            $select->bindParam (":category", $category, PDO::PARAM_INT);
            $select->execute();
            return $select;
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
        }

        function pagetotale($prodparpage)
        {
            $db = config::getConnexion();
            $prodsTotalesReq = $db->query('SELECT id FROM products');
            $prodsTotales = $prodsTotalesReq->rowCount();
            $prodsTotales = ceil($prodsTotales/$prodparpage);
            return $prodsTotales;
        }

        function pagination($prodparpage,$depart)
        {
            $db = config::getConnexion();
            $produit = $db->query('SELECT * FROM products ORDER BY id DESC LIMIT '.$depart.','.$prodparpage);
            return $produit;
        }
  }
		
?>