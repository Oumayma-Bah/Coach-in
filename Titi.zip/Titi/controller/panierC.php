<?PHP
    include "../config.php";


    class PanierC {

    public function afficherPanier(){
        $sql="SELECT * FROM `Panier`";
        $db=Config::getConnexion();
        try{
            return $db->query($sql);
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
    }
        public function afficherProduit(){
            $sql="SELECT * FROM `products`";
            $db=Config::getConnexion();
            try{
                return $db->query($sql);
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
        }
  function affichernameProduit($id){
        $sql="SELECT prod.name as noom FROM `Panier` as pan INNER JOIN products as prod on pan.id_produit=prod.id where pan.id_produit=$id";
        $db = config::getConnexion();
        try{
            $req = $db->prepare($sql);
            $req->execute();
            foreach ($req as $row):
                {
                    return $row['noom'];
                }
            endforeach;


        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

        function countpanier(){
            $sql="SELECT count(*) as cunt FROM `Panier`";
            $db = config::getConnexion();
            try{
                $req = $db->prepare($sql);
                $req->execute();
                foreach ($req as $row):
                    {
                        return $row['cunt'];
                    }
                endforeach;


            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
        }

        public function recupererPanier($id){
            $sql="SELECT * FROM `Panier` where id=".$id;
            $db=Config::getConnexion();
            try{

                return $db->query($sql);
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
        }


    function ajouterPanier(Panier  $Panier){
            $sql="INSERT INTO Panier (image, id_produit, prix,quantite) 
            VALUES (:image, :id_produit, :prix,:quantite)";
            $db = config::getConnexion();
            try{
                $query = $db->prepare($sql);
            
                $query->execute([
                    'image' => $Panier->getImage(),
                    'id_produit' => $Panier->getIdProduit(),
                    'prix' => $Panier->getPrix(),
                    'quantite' => $Panier->getQuantite()
                ]);
            } catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
}

        function supprimerPanier($id){
            $sql="DELETE FROM Panier where id= :id";
            $db = config::getConnexion();
            $req=$db->prepare($sql);
            $req->bindValue(':id',$id);
            try{
                $req->execute();
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
        }

        function modifierPanier($id, Panier $Panier){
            $sql="UPDATE Panier SET  image=:image,id_produit=:id_produit,prix=:prix,quantite=:quantite WHERE id=:id";

            $db = config::getConnexion();
            //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
            try{
                $req=$db->prepare($sql);

                $req->bindValue(':id',$id);
                $req->bindValue(':image',$Panier->getImage());
                $req->bindValue(':id_produit',$Panier->getIdProduit());
                $req->bindValue(':prix',$Panier->getPrix());
                $req->bindValue(':quantite',$Panier->getQuantite());
                $req->execute();
            }
            catch (Exception $e){
                echo " Erreur ! ".$e->getMessage();
                echo " Les datas : " ;

            }

        }

    }

?>
