<?PHP
class Produit{

	private $id;
	private $product_title;
	private $prix;
    private $final_price;
	private $tax;
	private $name;
	private $quantity;
	private $description;
	private $category;
	private $sale;
	private $size;
    private $image;

    public function __construct($product_title,$prix,$final_price,$tax,$name,$quantity,$description,$category,$sale,$size,$image)
    {
        $this->$product_title = $product_title;
        $this->$prix = $prix;
        $this->$final_price = $final_price;
        $this->$tax = $tax;
        $this->$name = $name;
        $this->$quantity = $quantity;
        $this->$description = $description;
        $this->$category = $category;
        $this->$sale = $sale;
        $this->$size = $size;
        $this->$image = $image;
    }


    public function getId(){
		return $this->id;
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getProduct_title(){
		return $this->product_title;
	}

	public function setProduct_title($product_title){
		$this->product_title = $product_title;
	}

	public function getPrix(){
		return $this->prix;
	}

	public function setPrix($prix){
		$this->prix = $prix;
	}

	public function getFinal_price(){
		return $this->final_price;
	}

	public function setFinal_price($final_price){
		$this->final_price = $final_price;
	}

	public function getTax(){
		return $this->tax;
	}

	public function setTax($tax){
		$this->tax = $tax;
	}

	public function getName(){
		return $this->name;
	}

	public function setName($name){
		$this->name = $name;
	}

	public function getQuantity(){
		return $this->quantity;
	}

	public function setQuantity($quantity){
		$this->quantity = $quantity;
	}

	public function getDescription(){
		return $this->description;
	}

	public function setDescription($description){
		$this->description = $description;
	}

	public function getCategory(){
		return $this->category;
	}

	public function setCategory($category){
		$this->category = $category;
	}

	public function getSale(){
		return $this->sale;
	}

	public function setSale($sale){
		$this->sale = $sale;
	}

	public function getSize(){
		return $this->size;
	}

	public function setSize($size){
		$this->size = $size;
	}

	public function getImage(){
		return $this->image;
	}

	public function setImage($image){
		$this->image = $image;
	}
	
}

?>