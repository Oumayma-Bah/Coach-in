<?php
include_once "../controller/panierC.php";
include_once "../model/panier.php";
if(isset($_POST["btn"]) && isset($_POST["image"]) && isset($_POST["id_produit"]) && isset($_POST["prix"])) {
    $v = new Panier($_POST["image"], $_POST["id_produit"], $_POST["prix"], 1);
    $vc = new PanierC();
    $vc->ajouterPanier($v);
    header('Location: shop-grid.php');
    echo "hahahaahha";
}

