<?php
include "../controller/panierC.php";
$vC=new PanierC();
if (isset($_POST["id"]) ){
    $vC->supprimerPanier($_POST["id"]);
    header('Location: shop-grid.php');
}
