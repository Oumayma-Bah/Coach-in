<?php
if (isset($_POST['ajouter'])) {
    try {
        $conn = new PDO('mysql:host=127.0.0.1;dbname=coachin', 'root', '');

        $name = htmlspecialchars($_POST['name']);
        $prix = htmlspecialchars($_POST['prix']);
        $quantity = htmlspecialchars($_POST['quantity']);
        $description = htmlspecialchars($_POST['description']);
        $category = htmlspecialchars($_POST['category']);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "insert into products (name,prix,quantity,description,category) values ('$name','$prix','$quantity','$description','$category')";
        $conn->exec($sql);
        echo '<div class="err"> New Product added successfully</div>';

        $mailto ="ahmed.tijani@esprit.tn";
        $mailSub = "Un Nouveau produit(".$_POST['name'].")";
        $mailMsg = "Nous avons un nouveau produit (".$_POST['name'].") en stock, venez visiter notre site!";
        require 'PHPMailer-master/PHPMailerAutoload.php';
        $mail = new PHPMailer();
        $mail ->IsSmtp();
        $mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $mail ->SMTPAuth = true;
        $mail->Debugoutput = 'html';
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPSecure = 'tls';
        $mail ->Port = 587; // or 587
        $mail ->IsHTML(true);
        $mail ->Username = "ahmed.tijani@esprit.tn";
        $mail ->Password = "191JMT2585";
        $mail ->SetFrom("ahmed.tijani@esprit.tn");
        $mail ->Subject = $mailSub;
        $mail ->Body = $mailMsg;
        $mail ->AddAddress($mailto);

        if(!$mail->Send())
        {
            echo '<body onLoad="alert(\'email non envoyé\')">';
        }
        else
        {
            echo '<body onLoad="alert(\'email envoyé\')">';
        }

    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }
}
$conn = null;
?>
<html>
<head>
    <meta charset="utf-8">
    <title>Gestion Produits</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
<div class="vl"></div>
<a href="index.php" class="logo">
    <img class="image_logo" src="logo.png" alt="logo" width="250px" height="200px"> </a>
<dt class="nav-item nav-category">
    <h2 class="pr">Gestion admin</h2>

</dt>
<dt class="nav-item menu-items">
    <a href="indexA.php" class="p">Gestion des articles</a>
</dt>
<br>
<dt class="nav-item menu-items">
    <a class="p" href="gestion utilisateurs.php">Gestion des utilisateurs</a>
</dt>
<br>
<dt class="nav-item menu-items">
    <a class="p" href="gestion coachs.php">Gestion des coachs</a>
</dt>
<br>
<dt class="nav-item menu-items">
    <a class="p" href="gestion nutritionnistes.php">Gestion des nutritionnistes</a>
</dt>
<br>
<dt class="nav-item menu-items">
    <a href="gestionProduits.php" class="p">Gestion des produits</a>
</dt>
<br>
<dt class="nav-item menu-items">
    <a href="gestion.php" class="p">Validation commandes</a>
</dt>
<br>
<dt class="nav-item menu-items">
    <a href="gestion.php" class="p">Validation paiements</a>
</dt>
<?php
session_start();
$bdd = new PDO('mysql:host=127.0.0.1;dbname=coachin', 'root', '');
try {
    $req = $bdd->prepare('SELECT * FROM products');
    $req->execute();
    $result = $req->fetchAll();
} catch (PDOException $e) {
    $e->getMessage();
}
foreach ($result as $row) {
    {
        echo '<h1 class="names">';
        echo "Nom:";
        echo $row['name'];
        echo "<br>";
        echo " Category:";
        echo $row['category'];
        echo "<br>";
        echo " Id:";
        echo $row['id'];
        echo "</h1>";
    }
}

?>

<div class="centrer">
    <form action="" method="POST">

        <label for="nom">Nom</label>
        <input class="form-control" type="text" name="name" required/><br>
        <label for="nom">quantity</label>
        <input class="form-control" type="number" name="quantity" required/><br>
        <label for="nom">Category</label>
        <input class="form-control" type="text" name="category" required/><br>
        <label for="nom">Description</label>
        <input class="form-control" type="text" name="description" required/><br>
        <label for="nom">Prix</label>
        <input class="form-control" type="Number" name="prix" required/><br>
        <div>
            <label>Importer une image</label></br>
            <input type="file" name="image" id="image" value="upload">
        </div>

        <input class="btn1" type="submit" name="ajouter" value="Ajouter"/>
    </form>
</div>
<div align="center">
    <form name="delete" action="" method="POST">
        <input class="btn" type="submit" name="delete" value="Supprimer un coach"/>
    </form>
    <br/>

</div>


<?php
if (isset($_POST['delete'])) {
    echo '<form method="GET" action="SupprimerProduit.php" enctype="multipart/form-data">
            <h1 class="ahla">
                    <label>ID du produit à supprimer</label></br>
                    <input type="text" id="id" name="id">
                <input type="submit" name="supprimer" value="Supprimer"></h1>
        </form>';

}
if (isset($_POST['getid'])) {
    $id_to_delete = htmlspecialchars($_POST['id']);
    try {
        $conn = new PDO('mysql:host=127.0.0.1;dbname=coachin', 'root', '');
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "DELETE FROM coachs WHERE id=$id_to_delete  ";

        $conn->exec($sql);
        header('location: http://localhost/COACHIN/backend/gestionProduits.php');
    } catch (PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }

    $conn = null;
}
?>

</body>
</html>