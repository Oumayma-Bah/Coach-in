<?php
$bdd = new PDO("mysql:host=127.0.0.1;dbname=articles;charset=utf8", "root", "");
$articles = $bdd->query('SELECT * FROM articles ORDER BY date_time_publication DESC');
$bdd = new PDO("mysql:host=127.0.0.1;dbname=blog;charset=utf8", "root", "");
$blog=$bdd->query('SELECT * FROM membres ORDER BY id DESC');
?>

<!DOCTYPE html>
<html>

<head>
   <title>Accueil</title>
   <meta charset="utf-8">
   
   <link rel="stylesheet" href="style.css" />

</head>
<body>
<a href="http://localhost/COACHIN/backend/index.php" >
<img src="logo.png"alt="logo" width="250px" height="200px"> </a>
<h1><span class="blue">&lt;</span>Table<span class="blue">&gt;</span> <span class="yellow">Registre</pan></h1>
<h2>COACH'in <a href="#" target="_blank">Blog</a></h2>

<table class="container">
	<thead>
		<tr>
         <th><h1>Articles</h1></th>
			<th><h1>modification</h1></th>
			<th><h1>supression</h1></th>
			
		</tr>
	</thead>
	<tbody>
               
   <ul class="articles">

    <?php while($a = $articles->fetch()) { ?>
		
		<tr>
			<td> <h2><a href="article.php?id=<?= $a['id'] ?>"><?= $a['titre'] ?></a></h2></td>
			<td><h3><a  href="redaction.php?edit=<?= $a['id'] ?>">Modifier</a><h3></td>
			<td><h3><a href="supprimer.php?id=<?= $a['id'] ?>">Supprimer</a><h3></td>
            
            <?php } ?>
     
            <ul>
		</tr>
		
	</tbody>
</table>

<h1><span class="blue">&lt;</span>Table<span class="blue">&gt;</span> <span class="yellow">Inscription</pan></h1>
<h2>COACH'in <a href="#" target="_blank">Blog</a></h2>
<table class="container">
	<thead>
		<tr>
        <th><h1>Nom</h1></th>
        
			<th><h1>Adresse mail</h1></th>
      
      <th><h1>titre</h1></th>
			
		</tr>
	</thead>
	<tbody>
               
   <ul class="articles">

    <?php while($a = $blog->fetch()) { ?>
		
		<tr>
			<td> <h3><a href=""><?= $a['pseudo'] ?>  </a></h3></td>
       
       <td> <h3><a href=""><?= $a['mail'] ?></a></h2></td>
      
      <td> <h2><a href=""><?= $a['mesage'] ?></a> </h2></td>   
            <?php } ?>
     
            <ul>
		</tr>
		
	</tbody>
</table>
</body>
<style>
  @charset "UTF-8";
@import url(https://fonts.googleapis.com/css?family=Open+Sans:300,400,700);

body {
  font-family: 'Open Sans', sans-serif;
  font-weight: 300;
  line-height: 1.42em;
  color:#A7A1AE;
  background-color:#191c24;
}

h1 {
  font-size:3em; 
  font-weight: 300;
  line-height:1em;
  text-align: center;
  color: #4DC3FA;
}

h2 {
  font-size:1em; 
  
  text-align: center;
  display: block;
  line-height:1em;
  padding-bottom: 2em;
  color: #FB667A;
  text-transform: uppercase;
  text-decoration: none;
  font-weight: 700
 
 
}



h2 a {
  font-weight: 700;
  text-transform: uppercase;
  color: #FB667A;
  text-decoration: none;
}
h3 a {
  font-weight: 700;
  text-transform: uppercase;
  color : #32CD32;
  text-decoration: none;
}

.blue { color: #185875; }
.yellow { color: #FFF842; }

.container th h1 {
	  font-weight: bold;
	  font-size: 1em;
  text-align: left;
  color: #185875;
}

.container td {
	  font-weight: normal;
	  font-size: 1em;
  -webkit-box-shadow: 0 2px 2px -2px #0E1119;
	   -moz-box-shadow: 0 2px 2px -2px #0E1119;
	        box-shadow: 0 2px 2px -2px #0E1119;
}

.container {
	  text-align: left;
	  overflow: hidden;
	  width: 80%;
	  margin: 0 auto;
  display: table;
  padding: 0 0 8em 0;
}

.container td, .container th {
	  padding-bottom: 2%;
	  padding-top: 2%;
  padding-left:2%;  
}

/* Background-color of the odd rows */
.container tr:nth-child(odd) {
	  background-color: #323C50;
}

/* Background-color of the even rows */
.container tr:nth-child(even) {
	  background-color: #2C3446;
}

.container th {
	  background-color: #1F2739;
}

.container td:first-child { color: #FB667A; }

.container tr:hover {
   background-color: #464A52;
-webkit-box-shadow: 0 6px 6px -6px #0E1119;
	   -moz-box-shadow: 0 6px 6px -6px #0E1119;
	        box-shadow: 0 6px 6px -6px #0E1119;
}

.container td:hover {
  background-color: #FFF842;
  color: #403E10;
  font-weight: bold;
  
  box-shadow: #7F7C21 -1px 1px, #7F7C21 -2px 2px, #7F7C21 -3px 3px, #7F7C21 -4px 4px, #7F7C21 -5px 5px, #7F7C21 -6px 6px;
  transform: translate3d(6px, -6px, 0);
  
  transition-delay: 0s;
	  transition-duration: 0.4s;
	  transition-property: all;
  transition-timing-function: line;
}

@media (max-width: 800px) {
.container td:nth-child(4),
.container th:nth-child(4) { display: none; }
}
 
 </style>

</html>