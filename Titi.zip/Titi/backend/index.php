<html>
<head>
	 <meta charset="utf-8">
	   <title>Coach'In Admin</title>
	           <link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="vl"></div>
	<a href="index.php" class="logo">
<img class="image_logo"src="logo.png"alt="logo" width="250px" height="200px" > </a>
		  <dt class="nav-item menu-items">
              <a href="gestionProduits.php" class="p">Gestion des produits</a>
          </dt>
</body>
</html>
<style type="text/css">
    .vl {
  border-left: 2px solid gray;
  height: 1000px;
  position: absolute;
  left: 25%;
  margin-left: -3px;
  top: 0;
}
</style>