<?php
$bdd = new PDO("mysql:host=127.0.0.1;dbname=articles;charset=utf8", "root", "");
if(isset($_GET['id']) AND !empty($_GET['id'])) {
   $get_id = htmlspecialchars($_GET['id']);
   $article = $bdd->prepare('SELECT * FROM articles WHERE id = ?');
   $article->execute(array($get_id));
   if($article->rowCount() == 1) {
      $article = $article->fetch();
      $titre = $article['titre'];
      $contenu = $article['contenu'];
   } else {
      die('Cet article n\'existe pas !');
   }
} else {
   die('Erreur');
}
?>
<!DOCTYPE html>
<html>
<head>
   <title>Article</title>
   <meta charset="utf-8">
   <link rel="stylesheet" href="style.css" />
</head>
<body>
   <h1><?= $titre ?></h1></br></br></br>
   <p><?= $contenu ?></p>
</body>

<style>
 h1
{
   font-size: 50px;
text-align: center; /* centré */
}

p
{
text-align: center; /* centré */
font-size:20px;

}


  </style>

</html>