<html>
<head>
	 <meta charset="utf-8">
	   <title>Coach'In Admin</title>
	           <link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="vl"></div>
	<a href="index.php" class="logo">
<img class="image_logo"src="logo.png"alt="logo" width="250px" height="200px" > </a>
		  <dt class="nav-item nav-category">
            <h2  class="pr">Gestion admin</h2>
            
          </dt>
          <dt class="nav-item menu-items">
              <a class="p" href="gestion utilisateurs.php">Gestion des utilisateurs</a>
          </dt><br>
          <dt class="nav-item menu-items">
              <a href="indexA.php" class="p">Gestion des articles</a>
          </dt><br>
            <dt class="nav-item menu-items">
              <a href="gestion.php" class="p">Gestion des produits</a>
          </dt><br>
          <dt class="nav-item menu-items">
              <a href="gestion.php" class="p">Validation commandes</a>
          </dt><br>
          <dt class="nav-item menu-items">
              <a href="gestion.php" class="p">Validation paiements</a>
          </dt>
</body>
</html>