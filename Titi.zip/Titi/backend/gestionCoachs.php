<?php
if(isset($_POST['ajouter'])){
try {
$conn = new PDO('mysql:host=127.0.0.1;dbname=espace_membre', 'root', '');

$nom = htmlspecialchars($_POST['nom']);
   $prenom = htmlspecialchars($_POST['prenom']);
   $pseudo = htmlspecialchars($_POST['pseudo']);
   $mail = htmlspecialchars($_POST['mail']);
   $mdp = sha1($_POST['mdp']);
   $diplome = htmlspecialchars($_POST['diplome']);
   $telephone = htmlspecialchars($_POST['telephone']);
   $adresse = htmlspecialchars($_POST['adresse']);
   $avatar = "unknown";
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$sql = "INSERT INTO coachs (nom,prenom,pseudo,mail,motdepasse,diplome,telephone,adresse,avatar)
  VALUES ('$nom','$prenom','$pseudo','$mail','$mdp','$diplome','$telephone','$adresse','$avatar')";
  $conn->exec($sql);
  echo '<div class="err"> New coach added successfully</div>';
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}}
$conn = null;
?>
<html>
<head>
    <meta charset="utf-8">
      <title>Gestion coachs</title>
              <link rel="stylesheet" href="style1.css">
</head>
<body>
   <div class="vl"></div>
   <a href="index.php" class="logo">
<img class="image_logo"src="logo.png"alt="logo" width="250px" height="200px" > </a>
        <dt class="nav-item nav-category">
            <h2  class="pr">Gestion admin</h2>
            
          </dt>
          <dt class="nav-item menu-items">
              <a href="indexA.php" class="p">Gestion des articles</a>
          </dt><br>
          <dt class="nav-item menu-items">
              <a class="p" href="gestion utilisateurs.php">Gestion des utilisateurs</a>
          </dt><br>
          <dt class="nav-item menu-items">
              <a class="p" href="gestion coachs.php">Gestion des coachs</a>
          </dt><br>
          <dt class="nav-item menu-items">
              <a class="p" href="gestion nutritionnistes.php">Gestion des nutritionnistes</a>
          </dt><br>
            <dt class="nav-item menu-items">
              <a href="gestion.php" class="p">Gestion des produits</a>
          </dt><br>
          <dt class="nav-item menu-items">
              <a href="gestion.php" class="p">Validation commandes</a>
          </dt><br>
          <dt class="nav-item menu-items">
              <a href="gestion.php" class="p">Validation paiements</a>
          </dt>
</body>
</html>
<?php
session_start();
$bdd = new PDO('mysql:host=127.0.0.1;dbname=espace_membre', 'root', '');
   try {
$req= $bdd->prepare('SELECT * FROM coachs');
$req->execute();
$result = $req->fetchAll();
}
catch(PDOException $e) {$e->getMessage();}
foreach ($result as $row) {
   {
   echo '<h1 class="names">';
   echo "Nom:";echo $row['nom'];echo " Prenom:";echo $row['prenom'];echo " Id:";echo $row['id'];
   echo "</h1>";
}}

if(isset($_POST['delete']))
{
   echo '<label class="tapez">Tapez l id de l utilisateur à supprimer</label>';
   echo '<form action=""';echo ' method="POST">';
   echo '
   <input name="id" class="ahla" required>
   <input class="btn" type="submit" name="getid" value="Confirmer" />
</form>';

}
if(isset($_POST['getid'])){
   $id_to_delete=htmlspecialchars($_POST['id']);
try {
  $conn = new PDO('mysql:host=127.0.0.1;dbname=espace_membre', 'root', '');
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $sql = "DELETE FROM coachs WHERE id=$id_to_delete  ";

  $conn->exec($sql);
  header('location: http://localhost/COACHIN/backend/gestion coachs.php');
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
}
?>
<html>
   <head>
      <title>COACH'IN</title>
      <meta charset="utf-8">

   </head>
   <body>
    <div class="centrer">
        <form action="" method="POST" >

        <label for="nom">Nom</label>
        <input class="form-control" type="text" name="nom" required /><br>
        <label for="nom">Prenom</label>
        <input class="form-control" type="text" name="prenom" required /><br>
        <label for="nom">Pseudo</label>
        <input class="form-control" type="text" name="pseudo" required /><br>
        <label for="nom">Mail</label>
        <input class="form-control" type="mail" name="mail" required /><br>
        <label for="nom">Mot de passe</label>
        <input class="form-control" type="password" name="mdp" required /><br>
        <label for="nom">Adresse</label>
        <input class="form-control" type="text" name="adresse" required /><br>
        <label for="nom">Numero de téléphone</label>
        <input class="form-control" type="numero" name="telephone" required /><br>
        <label for="nom">Diplome</label>
        <input class="form-control" type="text" name="diplome" required /><br>

      <input class="btn1" type="submit" name="ajouter" value="Ajouter" />
    </form></div>
      <div align="center">
<form name="delete" action="" method="POST">
   <input class="btn" type="submit" name="delete" value="Supprimer un coach" />
</form>
         <br />

      </div>
   </body>
</html>