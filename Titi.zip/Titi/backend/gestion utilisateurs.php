<?php session_start(); ?>
<html>
<head>
    <meta charset="utf-8">
      <title>Coach'In Admin</title>
              <link rel="stylesheet" href="style1.css">
</head>
<body>
   <div class="vl"></div>
   <a href="index.php" class="logo">
<img class="image_logo"src="logo.png"alt="logo" width="250px" height="200px" > </a>
        <dt class="nav-item nav-category">
            <h2  class="pr">Gestion admin</h2>
            
          </dt>
          <dt class="nav-item menu-items">
              <a href="indexA.php" class="p">Gestion des articles</a>
          </dt><br>
          <dt class="nav-item menu-items">
              <a class="p" href="gestion utilisateurs.php">Gestion des utilisateurs</a>
          </dt><br>
          <dt class="nav-item menu-items">
              <a class="p" href="gestion coachs.php">Gestion des coachs</a>
          </dt><br>
          <dt class="nav-item menu-items">
              <a class="p" href="gestion nutritionnistes.php">Gestion des nutritionnistes</a>
          </dt><br>
            <dt class="nav-item menu-items">
              <a href="gestion.php" class="p">Gestion des produits</a>
          </dt><br>
          <dt class="nav-item menu-items">
              <a href="gestion.php" class="p">Validation commandes</a>
          </dt><br>
          <dt class="nav-item menu-items">
              <a href="gestion.php" class="p">Validation paiements</a>
          </dt>
</body>
</html>

<?php
$bdd = new PDO('mysql:host=127.0.0.1;dbname=espace_membre', 'root', '');
   try {
$req= $bdd->prepare('SELECT * FROM members');
$req->execute();
$result = $req->fetchAll();
}
catch(PDOException $e) {$e->getMessage();}
foreach ($result as $row) {
   {
   echo '<h1 class="names">';
   echo "Nom:";echo $row['nom'];echo " Prenom:";echo $row['prenom'];echo " Id:";echo $row['id'];
   echo "</h1>";
}}

if(isset($_POST['delete']))
{
   echo '<label class="tapez">Tapez l id de l utilisateur à supprimer</label>';
   echo '<form action=""';echo ' method="POST">';
   echo '
   <input name="id" class="ahla" required>
   <input class="btn" type="submit" name="getid" value="Confirmer" />
</form>';

}
if(isset($_POST['getid'])){
   $id_to_delete=htmlspecialchars($_POST['id']);
try {
  $conn = new PDO('mysql:host=127.0.0.1;dbname=espace_membre', 'root', '');
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $sql = "DELETE FROM members WHERE id=$id_to_delete  ";

  $conn->exec($sql);
  header('location: http://localhost/COACHIN/backend/gestion utilisateurs.php');
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
}
$bdd = new PDO('mysql:host=127.0.0.1;dbname=espace_membre', 'root', '');
try {
$req= $bdd->prepare('SELECT * FROM nb_connections');
$req->execute();
$result = $req->fetchAll();
}
catch(PDOException $e) {$e->getMessage();}
$n1=$n2=$n3=$n4=$n5=$n6=$n7=0;  
$dateTime = new DateTime();
$dateTime->modify('-6 day');
$d1=$dateTime;$day1=$dateTime->format("l");
$dateTime = new DateTime();
$dateTime->modify('-5 day');
$d2=$dateTime;$day2=$dateTime->format("l");
$dateTime = new DateTime();
$dateTime->modify('-4 day');
$d3=$dateTime;$day3=$dateTime->format("l");
$dateTime = new DateTime();
$dateTime->modify('-3 day');
$d4=$dateTime;$day4=$dateTime->format("l");
$dateTime = new DateTime();
$dateTime->modify('-2 day');
$d5=$dateTime;$day5=$dateTime->format("l");
$dateTime = new DateTime();
$dateTime->modify('-1 day');
$d6=$dateTime;$day6=$dateTime->format("l");
$dateTime = new DateTime();
$d7=$dateTime;$day7=$dateTime->format("l");

foreach ($result as $row) {
if($row['date']==$d1->format("Y-m-d")){$n1++;}
if($row['date']==$d2->format("Y-m-d")){$n2++;}
if($row['date']==$d3->format("Y-m-d")){$n3++;}
if($row['date']==$d4->format("Y-m-d")){$n4++;}
if($row['date']==$d5->format("Y-m-d")){$n5++;}
if($row['date']==$d6->format("Y-m-d")){$n6++;}
if($row['date']==$d7->format("Y-m-d")){$n7++;}
}
?>
<html>
   <head>
      <title>COACH'IN</title>
      <meta charset="utf-8">
      <link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="style_graph.css">

   </head>
   <body>
      <div align="center">
<form name="delete" action="" method="POST">
   <input class="btn" type="submit" name="delete" value="Supprimer un utilisateur" />
</form>

         <br />

</body>
</html>
<table id="q-graph">
  <caption class="ttt"style="font-size: 30px">Total number of visitors: <?php  $ch=$_SESSION['index'];echo $ch;?></caption>
<caption class="ttt"style="font-size: 30px">Number of logins last week</caption>

<thead>
<tr>
<th></th>
</tr>
<div class="centrer">
</thead>
<tbody>
<tr class="qtr" id="q1">
<th scope="row"><?php echo$day1;?></th>
<td class="sent bar" style="height: <?php echo($n1*20);?>px;"><p><?php echo$n1;?></p></td>
</tr>
<tr class="qtr" id="q2">
<th scope="row"><?php echo$day2;?></th>
<td class="sent bar" style="height: <?php echo($n2*20);?>px;"><p><?php echo$n2;?></p></td>
</tr>
<tr class="qtr" id="q3">
<th scope="row"><?php echo$day3;?></th>
<td class="sent bar" style="height: <?php echo($n3*20);?>px;"><p><?php echo$n3;?></p></td>
</tr>
<tr class="qtr" id="q4">
<th scope="row"><?php echo$day4;?></th>
<td class="sent bar" style="height: <?php echo($n4*20);?>px;"><p><?php echo$n4;?></p></td>
</tr>
</tr>
<tr class="qtr" id="q5">
<th scope="row"><?php echo$day5;?></th>
<td class="sent bar" style="height: <?php echo($n5*20);?>px;"><p><?php echo$n5;?></p></td>
</tr>
</tr>
<tr class="qtr" id="q6">
<th scope="row"><?php echo$day6;?></th>
<td class="sent bar" style="height: <?php echo($n6*20);?>px;"><p><?php echo$n6;?></p></td>
</tr>
</tr>
<tr class="qtr" id="q7">
<th scope="row"><?php echo$day7;?></th>
<td class="sent bar" style="height: <?php echo($n7*20);?>px;"><p><?php echo$n7;?></p></td>
</tr>
</tbody>
</table>
</div>
      </div>

   </body>
</html>