<?PHP
include "../controller/produitC.php";

if (isset($_GET["id"])) {
	
	$produit1C=new ProduitC();
	$produit1C->supprimerproduit($_GET["id"]);
	echo "ok";
	header('Location:gestionProduits.php');

}
else{
	echo "NON";
}

?>